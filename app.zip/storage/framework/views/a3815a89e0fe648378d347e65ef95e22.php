<?php $__env->startSection('title', 'Businesses'); ?>
<?php $__env->startSection('page-title', 'Businesses'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h3 class="text-lg font-semibold text-gray-900">Manage Businesses</h3>
            <p class="text-sm text-gray-600 mt-1">View and manage all registered businesses</p>
        </div>
        <a href="<?php echo e(route('admin.businesses.create')); ?>" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 flex items-center">
            <i class="fas fa-plus mr-2"></i> Add Business
        </a>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <form method="GET" action="<?php echo e(route('admin.businesses.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-xs font-medium text-gray-700 mb-1">Search</label>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Name, email, website..." 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-primary focus:border-primary">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-700 mb-1">Status</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-primary focus:border-primary">
                    <option value="">All</option>
                    <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-700 mb-1">Website Status</label>
                <select name="website_status" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-primary focus:border-primary">
                    <option value="">All</option>
                    <option value="approved" <?php echo e(request('website_status') === 'approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="pending" <?php echo e(request('website_status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="none" <?php echo e(request('website_status') === 'none' ? 'selected' : ''); ?>>No Website</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-700 mb-1">KYC Status</label>
                <select name="kyc_status" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-primary focus:border-primary">
                    <option value="">All</option>
                    <option value="verified" <?php echo e(request('kyc_status') === 'verified' ? 'selected' : ''); ?>>Verified</option>
                    <option value="pending" <?php echo e(request('kyc_status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="not_submitted" <?php echo e(request('kyc_status') === 'not_submitted' ? 'selected' : ''); ?>>Not Submitted</option>
                </select>
            </div>
            <div class="md:col-span-4 flex justify-end">
                <button type="submit" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 text-sm">
                    <i class="fas fa-filter mr-2"></i> Apply Filters
                </button>
                <?php if(request()->hasAny(['search', 'status', 'website_status', 'kyc_status'])): ?>
                    <a href="<?php echo e(route('admin.businesses.index')); ?>" class="ml-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm">
                        Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Business</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Website</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Balance</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($business->name); ?></div>
                            <div class="text-xs text-gray-500 mt-1">
                                <span class="inline-flex items-center">
                                    <?php if($business->verifications_count > 0): ?>
                                        <?php
                                            $latestVerification = $business->verifications->first();
                                        ?>
                                        <?php if($latestVerification && $latestVerification->status === 'approved'): ?>
                                            <i class="fas fa-check-circle text-green-500 mr-1"></i>
                                            <span class="text-green-600">KYC Verified</span>
                                        <?php elseif($latestVerification && in_array($latestVerification->status, ['pending', 'under_review'])): ?>
                                            <i class="fas fa-clock text-yellow-500 mr-1"></i>
                                            <span class="text-yellow-600">KYC Pending</span>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-red-500 mr-1"></i>
                                            <span class="text-red-600">KYC Rejected</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-exclamation-circle text-gray-400 mr-1"></i>
                                        <span class="text-gray-500">No KYC</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($business->email); ?></td>
                        <td class="px-6 py-4">
                            <?php if($business->website): ?>
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e($business->website); ?>" target="_blank" class="text-sm text-primary hover:underline truncate max-w-xs">
                                        <?php echo e(Str::limit($business->website, 30)); ?>

                                    </a>
                                    <?php if($business->website_approved): ?>
                                        <span class="px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-xs text-gray-400">No website</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm font-medium text-gray-900">₦<?php echo e(number_format($business->balance, 2)); ?></td>
                        <td class="px-6 py-4">
                            <?php if($business->is_active): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Active</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm">
                            <a href="<?php echo e(route('admin.businesses.show', $business)); ?>" class="text-primary hover:underline mr-3">View</a>
                            <a href="<?php echo e(route('admin.businesses.edit', $business)); ?>" class="text-primary hover:underline">Edit</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">No businesses found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($businesses->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-200">
            <?php echo e($businesses->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/admin/businesses/index.blade.php ENDPATH**/ ?>