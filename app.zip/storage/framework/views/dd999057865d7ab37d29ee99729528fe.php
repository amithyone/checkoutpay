<?php $__env->startSection('title', 'Email Accounts'); ?>
<?php $__env->startSection('page-title', 'Email Accounts'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h3 class="text-lg font-semibold text-gray-900">Manage Email Accounts</h3>
            <p class="text-sm text-gray-600 mt-1">Configure email accounts for monitoring bank transfer notifications</p>
        </div>
        <a href="<?php echo e(route('admin.email-accounts.create')); ?>" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 flex items-center">
            <i class="fas fa-plus mr-2"></i> Add Email Account
        </a>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Host/Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Businesses</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $emailAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 text-sm font-medium text-gray-900"><?php echo e($emailAccount->name); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($emailAccount->email); ?></td>
                        <td class="px-6 py-4 text-sm">
                            <?php if(($emailAccount->method ?? 'imap') === 'gmail_api'): ?>
                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800">Gmail API</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">IMAP</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600">
                            <?php if(($emailAccount->method ?? 'imap') === 'gmail_api'): ?>
                                <?php if($emailAccount->gmail_authorized ?? false): ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">Authorized</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">Not Authorized</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($emailAccount->host); ?>:<?php echo e($emailAccount->port); ?>

                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <?php if($emailAccount->is_active): ?>
                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">Active</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600">
                            <?php echo e($emailAccount->businesses()->count()); ?> business(es)
                        </td>
                        <td class="px-6 py-4 text-sm">
                            <div class="flex items-center space-x-2">
                                <?php if(($emailAccount->method ?? 'imap') === 'gmail_api' && !($emailAccount->gmail_authorized ?? false)): ?>
                                    <a href="<?php echo e(route('admin.email-accounts.gmail.authorize', $emailAccount)); ?>" 
                                        class="text-purple-600 hover:text-purple-900" title="Authorize Gmail">
                                        <i class="fas fa-key"></i> Authorize
                                    </a>
                                <?php endif; ?>
                                <button onclick="testConnection(<?php echo e($emailAccount->id); ?>)" 
                                    class="text-blue-600 hover:text-blue-900" title="Test Connection">
                                    <i class="fas fa-plug"></i>
                                </button>
                                <a href="<?php echo e(route('admin.email-accounts.edit', $emailAccount)); ?>" 
                                    class="text-primary hover:text-primary/80" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.email-accounts.destroy', $emailAccount)); ?>" 
                                    method="POST" class="inline" 
                                    onsubmit="return confirm('Are you sure? This will remove email account assignment from businesses.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-900" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-4 text-center text-sm text-gray-500">
                            No email accounts found. <a href="<?php echo e(route('admin.email-accounts.create')); ?>" class="text-primary hover:underline">Create one</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($emailAccounts->hasPages()): ?>
    <div class="flex justify-center">
        <?php echo e($emailAccounts->links()); ?>

    </div>
    <?php endif; ?>
</div>

<script>
function testConnection(id) {
    fetch(`/admin/email-accounts/${id}/test-connection`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('✅ Connection successful!');
        } else {
            alert('❌ Connection failed: ' + data.message);
        }
    })
    .catch(error => {
        alert('❌ Error testing connection: ' + error.message);
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/admin/email-accounts/index.blade.php ENDPATH**/ ?>