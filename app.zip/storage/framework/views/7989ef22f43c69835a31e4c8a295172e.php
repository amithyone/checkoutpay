<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - <?php echo e(\App\Models\Setting::get('site_name', 'CheckoutPay')); ?></title>
    <?php if(\App\Models\Setting::get('site_favicon')): ?>
        <link rel="icon" type="image/png" href="<?php echo e(asset('storage/' . \App\Models\Setting::get('site_favicon'))); ?>">
    <?php endif; ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            DEFAULT: '#3C50E0',
                        },
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-2xl">
        <!-- Header -->
        <div class="text-center mb-8">
            <?php
                $logo = \App\Models\Setting::get('site_logo');
                $siteName = \App\Models\Setting::get('site_name', 'CheckoutPay');
            ?>
            <?php if($logo && file_exists(storage_path('app/public/' . $logo))): ?>
                <div class="flex justify-center mb-4">
                    <img 
                        src="<?php echo e(asset('storage/' . $logo)); ?>" 
                        alt="<?php echo e($siteName); ?>" 
                        class="h-16 sm:h-20 object-contain max-w-full"
                        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                    >
                    <div class="hidden items-center justify-center w-16 h-16 bg-primary rounded-lg">
                        <i class="fas fa-lock text-white text-2xl"></i>
                    </div>
                </div>
            <?php else: ?>
                <div class="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-lg mb-4">
                    <i class="fas fa-lock text-white text-2xl"></i>
                </div>
            <?php endif; ?>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Secure Payment</h1>
            <p class="text-gray-600">Complete your payment using the details below</p>
        </div>

        <!-- Payment Form Card -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                
                <input type="hidden" name="business_id" value="<?php echo e($business->id); ?>">
                <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                <input type="hidden" name="service" value="<?php echo e($service ?? ''); ?>">
                <input type="hidden" name="return_url" value="<?php echo e($returnUrl); ?>">
                <input type="hidden" name="cancel_url" value="<?php echo e($cancelUrl); ?>">

                <!-- Business Info -->
                <div class="bg-gray-50 rounded-lg p-4 mb-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Paying to</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($business->name); ?></p>
                        </div>
                        <div class="text-right">
                            <p class="text-sm text-gray-600">Amount</p>
                            <p class="text-2xl font-bold text-primary">₦<?php echo e(number_format($amount, 2)); ?></p>
                        </div>
                    </div>
                    <?php if($service): ?>
                    <div class="mt-3 pt-3 border-t border-gray-200">
                        <p class="text-sm text-gray-600">Service/Product</p>
                        <p class="text-sm font-medium text-gray-900"><?php echo e($service); ?></p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Name Field -->
                <div>
                    <label for="payer_name" class="block text-sm font-medium text-gray-700 mb-2">
                        Full Name <span class="text-red-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="payer_name" 
                        name="payer_name" 
                        required
                        placeholder="Enter your name as it appears on your bank account"
                        value="<?php echo e(old('payer_name')); ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-primary focus:border-primary transition-colors <?php $__errorArgs = ['payer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    >
                    <p class="mt-1 text-xs text-gray-500">Enter the exact name on your bank account</p>
                    <?php $__errorArgs = ['payer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Error Messages -->
                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-circle text-red-600 mt-0.5 mr-3"></i>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-red-900 mb-1">Error</p>
                                <ul class="text-sm text-red-700 list-disc list-inside">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Submit Button -->
                <button 
                    type="submit" 
                    id="submitBtn"
                    class="w-full bg-primary text-white py-3 px-6 rounded-lg font-medium hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <span id="submitText">Continue to Payment</span>
                    <i class="fas fa-arrow-right ml-2" id="submitIcon"></i>
                </button>

                <!-- Cancel Link -->
                <div class="text-center">
                    <a href="<?php echo e($cancelUrl); ?>" class="text-sm text-gray-600 hover:text-gray-900">Cancel Payment</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Prevent double submission
        document.querySelector('form').addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            const submitText = document.getElementById('submitText');
            const submitIcon = document.getElementById('submitIcon');
            
            submitBtn.disabled = true;
            submitText.textContent = 'Processing...';
            submitIcon.className = 'fas fa-spinner fa-spin ml-2';
        });
    </script>
</body>
</html>
<?php /**PATH /home/checzspw/public_html/resources/views/checkout/show.blade.php ENDPATH**/ ?>