<?php $__env->startSection('title', 'Edit Business'); ?>
<?php $__env->startSection('page-title', 'Edit Business'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form action="<?php echo e(route('admin.businesses.update', $business)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="space-y-6">
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Business Name *</label>
                    <input type="text" name="name" id="name" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"
                        value="<?php echo e(old('name', $business->name)); ?>">
                </div>

                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                    <input type="email" name="email" id="email" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"
                        value="<?php echo e(old('email', $business->email)); ?>">
                </div>

                <div>
                    <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="text" name="phone" id="phone"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"
                        value="<?php echo e(old('phone', $business->phone)); ?>">
                </div>

                <div>
                    <label for="address" class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                    <textarea name="address" id="address" rows="3"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"><?php echo e(old('address', $business->address)); ?></textarea>
                </div>

                <div>
                    <label for="website" class="block text-sm font-medium text-gray-700 mb-1">Website URL</label>
                    <input type="url" name="website" id="website"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"
                        value="<?php echo e(old('website', $business->website)); ?>" placeholder="https://yourwebsite.com">
                    <p class="text-xs text-gray-500 mt-1">Website must be approved before business can request account numbers</p>
                </div>

                <div>
                    <label for="webhook_url" class="block text-sm font-medium text-gray-700 mb-1">Webhook URL</label>
                    <input type="url" name="webhook_url" id="webhook_url"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"
                        value="<?php echo e(old('webhook_url', $business->webhook_url)); ?>">
                </div>

                <div>
                    <label for="email_account_id" class="block text-sm font-medium text-gray-700 mb-1">Email Account</label>
                    <select name="email_account_id" id="email_account_id"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-primary focus:border-primary">
                        <option value="">-- Select Email Account --</option>
                        <?php $__currentLoopData = $emailAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($emailAccount->id); ?>" <?php echo e(old('email_account_id', $business->email_account_id) == $emailAccount->id ? 'selected' : ''); ?>>
                                <?php echo e($emailAccount->name); ?> (<?php echo e($emailAccount->email); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">Select which email account to monitor for this business's payments</p>
                </div>

                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $business->is_active) ? 'checked' : ''); ?> class="mr-2">
                        <span class="text-sm text-gray-700">Active</span>
                    </label>
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                    <a href="<?php echo e(route('admin.businesses.show', $business)); ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90">
                        Update Business
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/admin/businesses/edit.blade.php ENDPATH**/ ?>