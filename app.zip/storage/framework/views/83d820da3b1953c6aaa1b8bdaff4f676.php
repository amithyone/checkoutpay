<?php $__env->startSection('title', 'Statistics'); ?>
<?php $__env->startSection('page-title', 'Statistics Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Period Selector -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900">View Statistics</h2>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('admin.stats.index', ['period' => 'daily'])); ?>" 
                   class="px-4 py-2 rounded-lg text-sm font-medium transition-colors <?php echo e($period === 'daily' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    Daily
                </a>
                <a href="<?php echo e(route('admin.stats.index', ['period' => 'monthly'])); ?>" 
                   class="px-4 py-2 rounded-lg text-sm font-medium transition-colors <?php echo e($period === 'monthly' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    Monthly
                </a>
                <a href="<?php echo e(route('admin.stats.index', ['period' => 'yearly'])); ?>" 
                   class="px-4 py-2 rounded-lg text-sm font-medium transition-colors <?php echo e($period === 'yearly' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    Yearly
                </a>
            </div>
        </div>
    </div>

    <!-- Summary Cards - Row 1 -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <!-- Total Amount -->
        <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg shadow-sm p-6 border-2 border-green-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Total Amount</p>
                    <h3 class="text-3xl font-bold text-gray-900">₦<?php echo e(number_format($stats['summary']['total_amount'], 2)); ?></h3>
                </div>
                <div class="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-money-bill-wave text-green-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <?php if($period === 'daily'): ?>
                    Last 30 days
                <?php elseif($period === 'monthly'): ?>
                    Last 12 months
                <?php else: ?>
                    Last 5 years
                <?php endif; ?>
            </div>
        </div>

        <!-- Total Transactions -->
        <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg shadow-sm p-6 border-2 border-blue-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Total Transactions</p>
                    <h3 class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['summary']['total_transactions'])); ?></h3>
                </div>
                <div class="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-exchange-alt text-blue-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <?php echo e(number_format($stats['summary']['approved_transactions'])); ?> approved
            </div>
        </div>

        <!-- Approved Transactions -->
        <div class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg shadow-sm p-6 border-2 border-purple-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Approved</p>
                    <h3 class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['summary']['approved_transactions'])); ?></h3>
                </div>
                <div class="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-check-circle text-purple-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <?php if($stats['summary']['total_transactions'] > 0): ?>
                    <?php echo e(round(($stats['summary']['approved_transactions'] / $stats['summary']['total_transactions']) * 100, 1)); ?>% approval rate
                <?php else: ?>
                    0% approval rate
                <?php endif; ?>
            </div>
        </div>

        <!-- Average -->
        <div class="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg shadow-sm p-6 border-2 border-yellow-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">
                        <?php if($period === 'daily'): ?>
                            Average Daily
                        <?php elseif($period === 'monthly'): ?>
                            Average Monthly
                        <?php else: ?>
                            Average Yearly
                        <?php endif; ?>
                    </p>
                    <h3 class="text-3xl font-bold text-gray-900">₦<?php echo e(number_format($stats['summary']['average_transaction'], 2)); ?></h3>
                </div>
                <div class="w-16 h-16 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-yellow-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                Per transaction
            </div>
        </div>
    </div>

    <!-- Summary Cards - Row 2 -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Total Match Similarity Score -->
        <div class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg shadow-sm p-6 border-2 border-purple-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Total Match Similarity Score</p>
                    <h3 class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['match_similarity']['total_score'])); ?></h3>
                </div>
                <div class="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-percentage text-purple-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <?php echo e(number_format($stats['match_similarity']['total_attempts'])); ?> attempts
                <br>
                Avg: <?php echo e(number_format($stats['match_similarity']['average_score'], 2)); ?>%
            </div>
        </div>

        <!-- Average Matching Time -->
        <div class="bg-gradient-to-br from-teal-50 to-cyan-50 rounded-lg shadow-sm p-6 border-2 border-teal-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Average Matching Time</p>
                    <h3 class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['matching_time']['average_minutes'], 1)); ?> min</h3>
                </div>
                <div class="w-16 h-16 bg-teal-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-stopwatch text-teal-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <?php echo e(number_format($stats['matching_time']['total_matched'])); ?> matched payments
            </div>
        </div>

        <!-- Account Numbers Payments Received -->
        <div class="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-lg shadow-sm p-6 border-2 border-indigo-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <p class="text-sm text-gray-600 mb-1">Account Numbers</p>
                    <h3 class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['account_numbers']['total'])); ?></h3>
                </div>
                <div class="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-credit-card text-indigo-600 text-2xl"></i>
                </div>
            </div>
            <div class="text-xs text-gray-500">
                <div class="mb-1">
                    Payments: <span class="font-semibold text-gray-900"><?php echo e(number_format($stats['account_numbers']['total_payments_received_count'])); ?></span>
                </div>
                <div class="mb-1">
                    Amount: <span class="font-semibold text-gray-900">₦<?php echo e(number_format($stats['account_numbers']['total_payments_received_amount'], 2)); ?></span>
                </div>
                <div>
                    Pool: <?php echo e($stats['account_numbers']['pool']); ?> • Business: <?php echo e($stats['account_numbers']['business_specific']); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- Current Period Stats -->
    <?php if(isset($stats['today']) || isset($stats['current_month']) || isset($stats['current_year'])): ?>
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">
            <?php if($period === 'daily'): ?>
                Today's Performance
            <?php elseif($period === 'monthly'): ?>
                Current Month Performance
            <?php else: ?>
                Current Year Performance
            <?php endif; ?>
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php
                $current = $stats['today'] ?? $stats['current_month'] ?? $stats['current_year'];
            ?>
            <div class="bg-gray-50 rounded-lg p-4">
                <p class="text-sm text-gray-600 mb-1">Amount</p>
                <p class="text-2xl font-bold text-gray-900">₦<?php echo e(number_format($current['amount'], 2)); ?></p>
            </div>
            <div class="bg-gray-50 rounded-lg p-4">
                <p class="text-sm text-gray-600 mb-1">Transactions</p>
                <p class="text-2xl font-bold text-gray-900"><?php echo e(number_format($current['transactions'])); ?></p>
            </div>
            <div class="bg-gray-50 rounded-lg p-4">
                <p class="text-sm text-gray-600 mb-1">Approved</p>
                <p class="text-2xl font-bold text-gray-900"><?php echo e(number_format($current['approved'])); ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Charts -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Amount Chart -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Amount Received</h3>
            <div class="relative" style="height: 400px; max-height: 400px; overflow: hidden;">
                <canvas id="amountChart"></canvas>
            </div>
        </div>

        <!-- Transaction Count Chart -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Transaction Count</h3>
            <div class="relative" style="height: 400px; max-height: 400px; overflow: hidden;">
                <canvas id="countChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Top Account Numbers and Top Businesses -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Top Account Numbers -->
        <?php if(isset($stats['top_account_numbers']) && $stats['top_account_numbers']->count() > 0): ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-900">Top Account Numbers by Payments</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rank</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Account Number</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Account Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Payments</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $stats['top_account_numbers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4">
                                <span class="text-sm font-medium text-gray-900">#<?php echo e($index + 1); ?></span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="text-sm font-medium text-gray-900"><?php echo e($account->account_number); ?></span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($account->account_name); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-900 font-medium">₦<?php echo e(number_format($account->payments_amount ?? 0, 2)); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-600"><?php echo e(number_format($account->payments_count ?? 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    <!-- Top Businesses -->
    <?php if(isset($stats['top_businesses']) && $stats['top_businesses']->count() > 0): ?>
    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Top Businesses</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rank</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Business</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Amount</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Transactions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $stats['top_businesses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900">#<?php echo e($index + 1); ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900"><?php echo e($business->name); ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-900">₦<?php echo e(number_format($business->total_amount, 2)); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo e(number_format($business->transaction_count)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    </div>

    <!-- Recent Payments -->
    <?php if(isset($stats['recent_payments']) && $stats['recent_payments']->count() > 0): ?>
    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
        <div class="p-6 border-b border-gray-200 flex items-center justify-between">
            <h3 class="text-lg font-semibold text-gray-900">Recent Payments</h3>
            <a href="<?php echo e(route('admin.payments.index')); ?>" class="text-sm text-primary hover:underline">View All</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Transaction</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Business</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $stats['recent_payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <a href="<?php echo e(route('admin.payments.show', $payment)); ?>" class="text-sm font-medium text-primary hover:underline">
                                <?php echo e($payment->transaction_id); ?>

                            </a>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($payment->business->name ?? 'N/A'); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-900">₦<?php echo e(number_format($payment->received_amount ?: $payment->amount, 2)); ?></td>
                        <td class="px-6 py-4">
                            <?php if($payment->status === 'approved'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                            <?php elseif($payment->status === 'pending'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($payment->created_at->format('M d, Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// Amount Chart
const amountCtx = document.getElementById('amountChart').getContext('2d');
const amountChart = new Chart(amountCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_column($stats['chart_data']['amounts']->toArray(), 'date'), 512) ?>,
        datasets: [{
            label: 'Amount (₦)',
            data: <?php echo json_encode(array_column($stats['chart_data']['amounts']->toArray(), 'amount'), 512) ?>,
            borderColor: 'rgb(34, 197, 94)',
            backgroundColor: 'rgba(34, 197, 94, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 1.5,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return '₦' + context.parsed.y.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₦' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Count Chart
const countCtx = document.getElementById('countChart').getContext('2d');
const countChart = new Chart(countCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($stats['chart_data']['counts']->toArray(), 'date'), 512) ?>,
        datasets: [{
            label: 'Transactions',
            data: <?php echo json_encode(array_column($stats['chart_data']['counts']->toArray(), 'count'), 512) ?>,
            backgroundColor: 'rgba(59, 130, 246, 0.5)',
            borderColor: 'rgb(59, 130, 246)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 1.5,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/admin/stats/index.blade.php ENDPATH**/ ?>