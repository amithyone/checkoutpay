<?php $__env->startSection('title', 'Notifications'); ?>
<?php $__env->startSection('page-title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-2xl font-bold text-gray-900">Notifications</h2>
            <p class="text-gray-600 mt-1">Stay updated with your account activity</p>
        </div>
        <form action="<?php echo e(route('business.notifications.read-all')); ?>" method="POST" class="inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
                Mark All as Read
            </button>
        </form>
    </div>

    <!-- Notifications List -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
        <div class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-6 hover:bg-gray-50 <?php echo e(!$notification->is_read ? 'bg-blue-50/50' : ''); ?>">
                <div class="flex items-start gap-4">
                    <div class="flex-shrink-0">
                        <?php if($notification->type === 'payment_received'): ?>
                            <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-money-bill-wave text-green-600"></i>
                            </div>
                        <?php elseif($notification->type === 'withdrawal_approved'): ?>
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-check-circle text-blue-600"></i>
                            </div>
                        <?php elseif($notification->type === 'verification_approved'): ?>
                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-id-card text-purple-600"></i>
                            </div>
                        <?php else: ?>
                            <div class="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-bell text-gray-600"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-900"><?php echo e($notification->title); ?></p>
                                <p class="text-sm text-gray-600 mt-1"><?php echo e($notification->message); ?></p>
                                <p class="text-xs text-gray-500 mt-2"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                            </div>
                            <?php if(!$notification->is_read): ?>
                                <form action="<?php echo e(route('business.notifications.read', $notification)); ?>" method="POST" class="ml-4">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-xs text-primary hover:underline">Mark as read</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-12 text-center">
                <i class="fas fa-bell-slash text-4xl mb-4 text-gray-300"></i>
                <p class="text-gray-500">No notifications</p>
            </div>
            <?php endif; ?>
        </div>

        <?php if($notifications->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200">
                <?php echo e($notifications->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/business/notifications/index.blade.php ENDPATH**/ ?>