<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page->meta_title ?? $page->title); ?> - CheckoutPay</title>
    <?php if($page->meta_description): ?>
    <meta name="description" content="<?php echo e($page->meta_description); ?>">
    <?php endif; ?>
    <?php if(\App\Models\Setting::get('site_favicon')): ?>
        <link rel="icon" type="image/png" href="<?php echo e(asset('storage/' . \App\Models\Setting::get('site_favicon'))); ?>">
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('storage/' . \App\Models\Setting::get('site_favicon'))); ?>">
    <?php endif; ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: { DEFAULT: '#3C50E0' },
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50">
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <article class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sm:p-8">
            <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6"><?php echo e($page->title); ?></h1>
            
            <div class="prose prose-sm sm:prose-base max-w-none">
                <?php echo $page->content; ?>

            </div>
        </article>
    </div>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/checzspw/public_html/resources/views/page.blade.php ENDPATH**/ ?>