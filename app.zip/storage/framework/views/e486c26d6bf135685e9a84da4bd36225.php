<?php $__env->startSection('title', 'Payment Details'); ?>
<?php $__env->startSection('page-title', 'Payment Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h3 class="text-lg font-semibold text-gray-900">Transaction: <?php echo e($payment->transaction_id); ?></h3>
                <?php if($statusChecksCount >= 3): ?>
                    <div class="mt-2 flex items-center space-x-2">
                        <span class="px-3 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                            <i class="fas fa-exclamation-triangle mr-1"></i> Needs Review (<?php echo e($statusChecksCount); ?> API checks)
                        </span>
                        <a href="<?php echo e(route('admin.payments.needs-review')); ?>" class="text-xs text-primary hover:underline">
                            View All Needing Review
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex items-center gap-3">
                <?php if($payment->status === 'pending'): ?>
                    <button onclick="checkMatchForPayment(<?php echo e($payment->id); ?>)" 
                        id="check-match-btn"
                        class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center check-match-payment-btn"
                        data-payment-id="<?php echo e($payment->id); ?>">
                        <i class="fas fa-search mr-2"></i> Check Match
                    </button>
                    <button onclick="showManualVerifyModal(<?php echo e($payment->id); ?>, '<?php echo e($payment->transaction_id); ?>', <?php echo e($payment->amount); ?>)" 
                        class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center">
                        <i class="fas fa-check-double mr-2"></i> Manual Verify
                    </button>
                    <button onclick="showManualApproveModal(<?php echo e($payment->id); ?>, '<?php echo e($payment->transaction_id); ?>', <?php echo e($payment->amount); ?>)" 
                        class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center">
                        <i class="fas fa-check-circle mr-2"></i> Manual Approve
                    </button>
                    <?php if(!$payment->expires_at || $payment->expires_at->isFuture()): ?>
                        <button onclick="markAsExpired(<?php echo e($payment->id); ?>)" 
                            class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 flex items-center">
                            <i class="fas fa-clock mr-2"></i> Mark as Expired
                        </button>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="relative group">
                    <button onclick="showDeleteModal(<?php echo e($payment->id); ?>, '<?php echo e($payment->transaction_id); ?>')" 
                        class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 flex items-center">
                        <i class="fas fa-trash mr-2"></i> Delete
                    </button>
                </div>
                <?php if($payment->status === 'approved'): ?>
                    <button onclick="resendWebhook(<?php echo e($payment->id); ?>)" 
                        id="resend-webhook-btn"
                        class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 flex items-center"
                        title="Resend webhook notification to business">
                        <i class="fas fa-paper-plane mr-2"></i> Resend Webhook
                    </button>
                    <span class="px-3 py-1 text-sm font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                <?php elseif($payment->status === 'pending'): ?>
                    <span class="px-3 py-1 text-sm font-medium bg-yellow-100 text-yellow-800 rounded-full">
                        Pending
                        <?php if($payment->expires_at && $payment->expires_at->isPast()): ?>
                            <span class="ml-1 text-red-600">(Expired)</span>
                        <?php endif; ?>
                    </span>
                <?php else: ?>
                    <span class="px-3 py-1 text-sm font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-6">
            <div>
                <label class="text-sm text-gray-600">Amount</label>
                <p class="text-lg font-bold text-gray-900">₦<?php echo e(number_format($payment->amount, 2)); ?></p>
            </div>
            <div>
                <label class="text-sm text-gray-600">Business</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->business->name ?? 'N/A'); ?></p>
            </div>
            <div>
                <label class="text-sm text-gray-600">Payer Name</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->payer_name ?? 'N/A'); ?></p>
            </div>
            <div>
                <label class="text-sm text-gray-600">Bank</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->bank ?? 'N/A'); ?></p>
            </div>
            <div>
                <label class="text-sm text-gray-600">Account Number</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->account_number ?? 'N/A'); ?></p>
            </div>
            <?php if($payment->accountNumberDetails): ?>
            <div>
                <label class="text-sm text-gray-600">Account Details</label>
                <p class="text-sm font-medium text-gray-900">
                    <?php echo e($payment->accountNumberDetails->account_name); ?> - <?php echo e($payment->accountNumberDetails->bank_name); ?>

                </p>
            </div>
            <?php endif; ?>
            <div>
                <label class="text-sm text-gray-600">Created At</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->created_at->format('M d, Y H:i:s')); ?></p>
            </div>
            <?php if($payment->matched_at): ?>
            <div>
                <label class="text-sm text-gray-600">Matched At</label>
                <p class="text-sm font-medium text-gray-900"><?php echo e($payment->matched_at->format('M d, Y H:i:s')); ?></p>
                <?php
                    $matchingTimeMinutes = $payment->created_at->diffInMinutes($payment->matched_at);
                ?>
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-stopwatch mr-1"></i>
                    Matching Time: <span class="font-semibold text-teal-600"><?php echo e($matchingTimeMinutes); ?> minutes</span>
                    (<?php echo e($payment->created_at->diffForHumans($payment->matched_at, true)); ?>)
                </p>
            </div>
            <?php elseif($payment->status === 'pending'): ?>
            <div>
                <label class="text-sm text-gray-600">Pending Time</label>
                <?php
                    $pendingMinutes = $payment->created_at->diffInMinutes(now());
                ?>
                <p class="text-sm font-medium text-yellow-600"><?php echo e($pendingMinutes); ?> minutes</p>
                <p class="text-xs text-gray-500 mt-1">
                    Created <?php echo e($payment->created_at->diffForHumans()); ?>

                </p>
            </div>
            <?php endif; ?>
            <?php if($payment->email_data && isset($payment->email_data['manual_verification'])): ?>
            <div>
                <label class="text-sm text-gray-600">Manual Verification</label>
                <div class="mt-1">
                    <span class="px-2 py-1 text-xs font-medium bg-indigo-100 text-indigo-800 rounded-full">
                        <i class="fas fa-check-double mr-1"></i> Verified
                    </span>
                    <p class="text-xs text-gray-500 mt-1">
                        By: <?php echo e($payment->email_data['manual_verification']['verified_by_name'] ?? 'Admin'); ?>

                        <?php if(isset($payment->email_data['manual_verification']['verified_at'])): ?>
                            - <?php echo e(\Carbon\Carbon::parse($payment->email_data['manual_verification']['verified_at'])->format('M d, Y H:i')); ?>

                        <?php endif; ?>
                    </p>
                    <?php if(isset($payment->email_data['manual_verification']['verification_notes']) && !empty($payment->email_data['manual_verification']['verification_notes'])): ?>
                        <p class="text-xs text-gray-600 mt-1 italic"><?php echo e($payment->email_data['manual_verification']['verification_notes']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if($payment->expires_at): ?>
            <div>
                <label class="text-sm text-gray-600">Expires At</label>
                <p class="text-sm font-medium <?php echo e($payment->expires_at->isPast() ? 'text-red-600' : ($payment->expires_at->diffInHours(now()) < 2 ? 'text-orange-600' : 'text-gray-900')); ?>">
                    <?php echo e($payment->expires_at->format('M d, Y H:i:s')); ?>

                </p>
                <p class="text-xs text-gray-500 mt-1">
                    <?php echo e($payment->expires_at->isPast() ? 'Expired' : 'Expires ' . $payment->expires_at->diffForHumans()); ?>

                </p>
            </div>
            <?php endif; ?>
        </div>

        <!-- API Status Checks Section -->
        <?php if($payment->statusChecks->count() > 0): ?>
        <div class="mt-6 pt-6 border-t border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-md font-semibold text-gray-900">
                    <i class="fas fa-sync-alt text-primary mr-2"></i>API Status Checks (<?php echo e($payment->statusChecks->count()); ?>)
                </h4>
                <?php if($statusChecksCount >= 3): ?>
                    <span class="px-3 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                        Needs Review
                    </span>
                <?php endif; ?>
            </div>
            <div class="space-y-3">
                <?php $__currentLoopData = $payment->statusChecks->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center gap-3">
                            <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                                <i class="fas fa-api mr-1"></i> API Check
                            </span>
                            <?php if($check->business): ?>
                                <span class="text-xs text-gray-600">
                                    Business: <?php echo e($check->business->name); ?>

                                </span>
                            <?php endif; ?>
                            <?php if($check->ip_address): ?>
                                <span class="text-xs text-gray-500">
                                    IP: <?php echo e($check->ip_address); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <span class="text-xs text-gray-500"><?php echo e($check->created_at->format('M d, H:i')); ?></span>
                    </div>
                    <p class="text-xs text-gray-600">Status at check: <span class="font-medium"><?php echo e(ucfirst($check->payment_status)); ?></span></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Match Attempts Section -->
        <?php if($payment->matchAttempts->count() > 0): ?>
        <div class="mt-6 pt-6 border-t border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <h4 class="text-md font-semibold text-gray-900">
                    <i class="fas fa-search-dollar text-primary mr-2"></i>Match Attempts (<?php echo e($payment->matchAttempts->count()); ?>)
                </h4>
                <a href="<?php echo e(route('admin.match-attempts.index', ['transaction_id' => $payment->transaction_id])); ?>" 
                   class="text-sm text-primary hover:underline">
                    View All <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
            <div class="space-y-3">
                <?php $__currentLoopData = $payment->matchAttempts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center gap-3">
                            <?php if($attempt->match_result === 'matched'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                                    <i class="fas fa-check-circle mr-1"></i> Matched
                                </span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
                                    <i class="fas fa-times-circle mr-1"></i> Unmatched
                                </span>
                            <?php endif; ?>
                            <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded">
                                <?php echo e($attempt->extraction_method ?? 'unknown'); ?>

                            </span>
                            <?php if($attempt->name_similarity_percent !== null): ?>
                                <span class="text-xs text-gray-600">
                                    Similarity: <?php echo e($attempt->name_similarity_percent); ?>%
                                </span>
                            <?php endif; ?>
                            <?php if($attempt->amount_diff): ?>
                                <span class="text-xs text-gray-600">
                                    Amount diff: ₦<?php echo e(number_format(abs($attempt->amount_diff), 2)); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <span class="text-xs text-gray-500"><?php echo e($attempt->created_at->format('M d, H:i')); ?></span>
                    </div>
                    <p class="text-sm text-gray-700"><?php echo e(Str::limit($attempt->reason, 150)); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if($payment->email_data): ?>
        <div class="mt-6 pt-6 border-t border-gray-200">
            <label class="text-sm text-gray-600 mb-2 block">Email Data</label>
            <pre class="bg-gray-50 p-4 rounded-lg text-xs overflow-x-auto"><?php echo e(json_encode($payment->email_data, JSON_PRETTY_PRINT)); ?></pre>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Delete Transaction</h3>
        <p class="text-sm text-gray-700 mb-6">
            Are you sure you want to delete transaction <span id="delete-transaction-id" class="font-mono font-semibold"></span>? 
            This action cannot be undone.
        </p>
        <form id="deleteForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="flex justify-end space-x-3">
                <button type="button" onclick="closeDeleteModal()" 
                    class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                    Cancel
                </button>
                <button type="submit" 
                    class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                    <i class="fas fa-trash mr-2"></i> Delete Transaction
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Manual Verify Modal -->
<div id="manualVerifyModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">
            <i class="fas fa-check-double text-indigo-600 mr-2"></i>Manually Verify Transaction
        </h3>
        <form id="manualVerifyForm" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Transaction ID</label>
                <p class="text-sm font-mono text-gray-900 bg-gray-50 p-2 rounded" id="verify-modal-transaction-id"></p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Expected Amount</label>
                <p class="text-lg font-bold text-gray-900" id="verify-modal-expected-amount"></p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Verified Amount <span class="text-red-500">*</span></label>
                <input type="number" name="verified_amount" step="0.01" min="0" required id="verify-modal-verified-amount"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary">
                <p class="text-xs text-gray-500 mt-1">Enter the amount you verified (defaults to expected amount)</p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Verification Notes</label>
                <textarea name="verification_notes" rows="3" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary text-sm" 
                    placeholder="Add notes about the verification (e.g., checked bank statement, confirmed receipt, etc.)..."></textarea>
            </div>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <p class="text-xs text-blue-800">
                    <i class="fas fa-info-circle mr-1"></i>
                    <strong>Note:</strong> This will mark the transaction as manually verified. You can approve it later using the "Manual Approve" button.
                </p>
            </div>
            <div class="flex justify-end space-x-3">
                <button type="button" onclick="closeManualVerifyModal()" 
                    class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                    Cancel
                </button>
                <button type="submit" 
                    class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    <i class="fas fa-check-double mr-2"></i> Verify Transaction
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Manual Approve Modal -->
<div id="manualApproveModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Manually Approve Transaction</h3>
        <form id="manualApproveForm" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Transaction ID</label>
                <p class="text-sm font-mono text-gray-900 bg-gray-50 p-2 rounded" id="modal-transaction-id"></p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Expected Amount</label>
                <p class="text-lg font-bold text-gray-900" id="modal-expected-amount"></p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Received Amount <span class="text-red-500">*</span></label>
                <input type="number" name="received_amount" step="0.01" min="0" required id="modal-received-amount"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary">
                <p class="text-xs text-gray-500 mt-1">Enter the actual amount received if different from expected</p>
            </div>
            <div class="mb-4">
                <label class="flex items-center space-x-2">
                    <input type="checkbox" name="is_mismatch" id="is-mismatch-checkbox" 
                        class="rounded border-gray-300 text-primary focus:ring-primary">
                    <span class="text-sm text-gray-700">Mark as amount mismatch</span>
                </label>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Link Email (Optional)</label>
                <select name="email_id" id="email-select"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary text-sm">
                    <option value="">-- No email link --</option>
                    <?php if(isset($unmatchedEmails) && $unmatchedEmails->count() > 0): ?>
                        <?php $__currentLoopData = $unmatchedEmails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($email->id); ?>">
                                <?php echo e($email->subject); ?> - <?php echo e($email->from_email); ?> - ₦<?php echo e(number_format($email->amount ?? 0, 2)); ?> 
                                (<?php echo e($email->email_date ? $email->email_date->format('M d, Y H:i') : 'No date'); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <p class="text-xs text-gray-500 mt-1">Select an email to link to this transaction. This will include email data in the webhook sent to the business.</p>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Admin Notes</label>
                <textarea name="admin_notes" rows="3" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary text-sm" 
                    placeholder="Add notes about why this is being manually approved..."></textarea>
            </div>
            <div class="flex justify-end space-x-3">
                <button type="button" onclick="closeManualApproveModal()" 
                    class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                    Cancel
                </button>
                <button type="submit" 
                    class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    <i class="fas fa-check-circle mr-2"></i> Approve & Credit Business
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function checkMatchForPayment(paymentId) {
    const btn = document.getElementById('check-match-btn');
    if (!btn) return;
    
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Checking...';
    
    fetch(`/admin/payments/${paymentId}/check-match`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>',
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP ${response.status}: ${text.substring(0, 200)}`);
            });
        }
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            return response.text().then(text => {
                throw new Error('Response is not JSON: ' + text.substring(0, 200));
            });
        }
        
        return response.json();
    })
    .then(data => {
        if (data.success) {
            if (data.matched) {
                alert(`✅ Payment matched and approved!\n\nEmail: ${data.email.subject || 'N/A'}\nFrom: ${data.email.from_email || 'N/A'}\nAmount: ₦${data.payment.amount.toLocaleString()}`);
                window.location.reload();
            } else {
                let message = '❌ No matching email found.\n\n';
                if (data.matches && data.matches.length > 0) {
                    message += 'Checked Emails:\n';
                    data.matches.forEach(match => {
                        message += `\n• ${match.email_subject || 'No Subject'}: ${match.reason}`;
                        if (match.time_diff_minutes !== null) {
                            message += ` (${match.time_diff_minutes} min difference)`;
                        }
                    });
                } else {
                    message += 'No unmatched emails found to check against.';
                }
                alert(message);
            }
        } else {
            alert('Error: ' + (data.message || 'Failed to check match'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error checking match: ' + error.message + '\n\nCheck browser console (F12) for details.');
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}

function markAsExpired(paymentId) {
    if (!confirm('Are you sure you want to mark this transaction as expired? This will stop all matching attempts.')) {
        return;
    }

    fetch(`/admin/payments/${paymentId}/mark-expired`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>',
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (response.ok) {
            return response.json().catch(() => ({ success: true }));
        }
        return response.json().then(data => Promise.reject(data));
    })
    .then(() => {
        window.location.reload();
    })
    .catch(error => {
        alert('Error: ' + (error.message || 'Failed to mark as expired'));
    });
}

function showDeleteModal(paymentId, transactionId) {
    const form = document.getElementById('deleteForm');
    form.action = `/admin/payments/${paymentId}`;
    document.getElementById('delete-transaction-id').textContent = transactionId;
    document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}

function showManualVerifyModal(paymentId, transactionId, expectedAmount) {
    const form = document.getElementById('manualVerifyForm');
    form.action = `/admin/payments/${paymentId}/manual-verify`;
    
    document.getElementById('verify-modal-transaction-id').textContent = transactionId;
    document.getElementById('verify-modal-expected-amount').textContent = '₦' + expectedAmount.toLocaleString('en-NG', {minimumFractionDigits: 2});
    document.getElementById('verify-modal-verified-amount').value = expectedAmount;
    
    document.getElementById('manualVerifyModal').classList.remove('hidden');
}

function closeManualVerifyModal() {
    document.getElementById('manualVerifyModal').classList.add('hidden');
}

function showManualApproveModal(paymentId, transactionId, expectedAmount) {
    const form = document.getElementById('manualApproveForm');
    form.action = `/admin/payments/${paymentId}/manual-approve`;
    
    document.getElementById('modal-transaction-id').textContent = transactionId;
    document.getElementById('modal-expected-amount').textContent = '₦' + expectedAmount.toLocaleString('en-NG', {minimumFractionDigits: 2});
    document.getElementById('modal-received-amount').value = expectedAmount;
    
    document.getElementById('manualApproveModal').classList.remove('hidden');
}

function closeManualApproveModal() {
    document.getElementById('manualApproveModal').classList.add('hidden');
}

function resendWebhook(paymentId) {
    const btn = document.getElementById('resend-webhook-btn');
    if (!btn) return;
    
    if (!confirm('Are you sure you want to resend the webhook notification to the business?')) {
        return;
    }
    
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Sending...';
    
    fetch(`/admin/payments/${paymentId}/resend-webhook`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>',
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => Promise.reject(data));
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert('✅ Webhook notification has been queued for resending successfully!');
        } else {
            alert('❌ Error: ' + (data.message || 'Failed to resend webhook'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('❌ Error: ' + (error.message || 'Failed to resend webhook. Please try again.'));
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}

// Auto-check mismatch if amounts differ
document.addEventListener('DOMContentLoaded', function() {
    const receivedAmountInput = document.getElementById('modal-received-amount');
    if (receivedAmountInput) {
        receivedAmountInput.addEventListener('input', function() {
            const expectedText = document.getElementById('modal-expected-amount').textContent;
            const expected = parseFloat(expectedText.replace(/[₦,]/g, '')) || 0;
            const received = parseFloat(this.value) || 0;
            const mismatchCheckbox = document.getElementById('is-mismatch-checkbox');
            
            if (mismatchCheckbox && Math.abs(expected - received) > 0.01) {
                mismatchCheckbox.checked = true;
            } else if (mismatchCheckbox) {
                mismatchCheckbox.checked = false;
            }
        });
    }
    
    // Close modal when clicking outside
    const modal = document.getElementById('manualApproveModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeManualApproveModal();
            }
        });
    }

    // Close delete modal when clicking outside
    const deleteModal = document.getElementById('deleteModal');
    if (deleteModal) {
        deleteModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeDeleteModal();
            }
        });
    }

    // Close verify modal when clicking outside
    const verifyModal = document.getElementById('manualVerifyModal');
    if (verifyModal) {
        verifyModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeManualVerifyModal();
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/admin/payments/show.blade.php ENDPATH**/ ?>