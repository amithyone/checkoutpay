<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4 lg:space-y-6 pb-20 lg:pb-0">
    <!-- Business ID Card -->
    <div class="bg-gradient-to-r from-primary to-primary/90 rounded-xl shadow-sm p-5 lg:p-6 text-white">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs lg:text-sm text-white/80 mb-1">Business ID</p>
                <h3 class="text-xl lg:text-2xl font-bold font-mono"><?php echo e(auth('business')->user()->business_id ?? auth('business')->user()->id); ?></h3>
                <p class="text-xs text-white/70 mt-2">Use this ID for API integrations and support requests</p>
            </div>
            <div class="w-12 h-12 lg:w-16 lg:h-16 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <i class="fas fa-id-card text-white text-xl lg:text-2xl"></i>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        <!-- Daily Revenue -->
        <div class="bg-white rounded-xl shadow-sm p-5 lg:p-6 border border-gray-200 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between mb-4">
                <div class="flex-1 min-w-0">
                    <p class="text-xs lg:text-sm text-gray-600 mb-1">Daily Revenue</p>
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900 truncate">₦<?php echo e(number_format($stats['today_revenue'] ?? 0, 2)); ?></h3>
                </div>
                <div class="w-10 h-10 lg:w-12 lg:h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0 ml-3">
                    <i class="fas fa-money-bill-wave text-green-600 text-lg lg:text-xl"></i>
                </div>
            </div>
            <div class="pt-3 border-t border-gray-100">
                <div class="flex items-center justify-between text-xs">
                    <span class="text-gray-600">Monthly: ₦<?php echo e(number_format($stats['monthly_revenue'] ?? 0, 2)); ?></span>
                    <span class="text-gray-600">Yearly: ₦<?php echo e(number_format($stats['yearly_revenue'] ?? 0, 2)); ?></span>
                </div>
            </div>
        </div>

        <!-- Current Balance -->
        <div class="bg-white rounded-xl shadow-sm p-5 lg:p-6 border border-gray-200 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between mb-4">
                <div class="flex-1 min-w-0">
                    <p class="text-xs lg:text-sm text-gray-600 mb-1">Current Balance</p>
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900 truncate">₦<?php echo e(number_format($stats['balance'], 2)); ?></h3>
                </div>
                <div class="w-10 h-10 lg:w-12 lg:h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 ml-3">
                    <i class="fas fa-wallet text-blue-600 text-lg lg:text-xl"></i>
                </div>
            </div>
            <div class="pt-3 border-t border-gray-100">
                <a href="<?php echo e(route('business.withdrawals.create')); ?>" class="text-xs text-primary hover:underline inline-flex items-center">
                    Request Withdrawal <i class="fas fa-arrow-right ml-1 text-xs"></i>
                </a>
            </div>
        </div>

        <!-- Total Transactions -->
        <div class="bg-white rounded-xl shadow-sm p-5 lg:p-6 border border-gray-200 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between mb-4">
                <div class="flex-1 min-w-0">
                    <p class="text-xs lg:text-sm text-gray-600 mb-1">Total Transactions</p>
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900"><?php echo e(number_format($stats['total_payments'])); ?></h3>
                </div>
                <div class="w-10 h-10 lg:w-12 lg:h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0 ml-3">
                    <i class="fas fa-exchange-alt text-purple-600 text-lg lg:text-xl"></i>
                </div>
            </div>
            <div class="pt-3 border-t border-gray-100">
                <div class="flex items-center text-xs space-x-2">
                    <span class="text-green-600">Approved: <?php echo e($stats['approved_payments']); ?></span>
                    <span class="text-gray-300">•</span>
                    <span class="text-yellow-600">Pending: <?php echo e($stats['pending_payments']); ?></span>
                </div>
            </div>
        </div>

        <!-- Pending Withdrawals -->
        <div class="bg-white rounded-xl shadow-sm p-5 lg:p-6 border border-gray-200 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between mb-4">
                <div class="flex-1 min-w-0">
                    <p class="text-xs lg:text-sm text-gray-600 mb-1">Pending Withdrawals</p>
                    <h3 class="text-xl lg:text-2xl font-bold text-gray-900"><?php echo e(number_format($stats['pending_withdrawals'])); ?></h3>
                </div>
                <div class="w-10 h-10 lg:w-12 lg:h-12 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0 ml-3">
                    <i class="fas fa-hand-holding-usd text-yellow-600 text-lg lg:text-xl"></i>
                </div>
            </div>
            <div class="pt-3 border-t border-gray-100">
                <a href="<?php echo e(route('business.withdrawals.index', ['status' => 'pending'])); ?>" class="text-xs text-primary hover:underline inline-flex items-center">
                    View All <i class="fas fa-arrow-right ml-1 text-xs"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Website Revenue Breakdown -->
    <?php if(count($websiteStats) > 0): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
        <div class="p-4 lg:p-6 border-b border-gray-200 flex items-center justify-between">
            <h3 class="text-base lg:text-lg font-semibold text-gray-900">
                <i class="fas fa-globe mr-2 text-primary"></i> Website Revenue Breakdown
            </h3>
            <a href="<?php echo e(route('business.websites.index')); ?>" class="text-xs lg:text-sm text-primary hover:underline">Manage Websites</a>
        </div>
        <div class="p-4 lg:p-6">
            <div class="space-y-4">
                <?php $__currentLoopData = $websiteStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $websiteStat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-gray-200 rounded-lg p-3 sm:p-4 hover:bg-gray-50 overflow-hidden">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                        <div class="flex-1 min-w-0">
                            <div class="flex flex-col sm:flex-row sm:items-center gap-2 mb-1">
                                <a href="<?php echo e($websiteStat['website']->website_url); ?>" target="_blank" class="text-primary hover:underline font-medium text-xs sm:text-sm truncate">
                                    <?php echo e(parse_url($websiteStat['website']->website_url, PHP_URL_HOST)); ?>

                                    <i class="fas fa-external-link-alt text-xs ml-1"></i>
                                </a>
                                <?php if($websiteStat['website']->is_approved): ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full self-start">
                                        <i class="fas fa-check-circle mr-1"></i> Approved
                                    </span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full self-start">
                                        <i class="fas fa-clock mr-1"></i> Pending
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-left sm:text-right min-w-0">
                            <p class="text-base sm:text-lg font-bold text-gray-900 break-words leading-tight">₦<?php echo e(number_format($websiteStat['total_revenue'], 2)); ?></p>
                            <p class="text-xs text-gray-500">Total: <?php echo e($websiteStat['total_payments']); ?> payments</p>
                        </div>
                    </div>
                    
                    <!-- Daily and Monthly Revenue Breakdown -->
                    <div class="grid grid-cols-2 gap-3 sm:gap-4 mt-4 pt-4 border-t border-gray-100">
                        <div class="bg-blue-50 rounded-lg p-3 min-w-0 overflow-hidden">
                            <p class="text-xs text-gray-600 mb-1">Today</p>
                            <p class="text-sm sm:text-base font-bold text-blue-900 break-words leading-tight">₦<?php echo e(number_format($websiteStat['today_revenue'], 2)); ?></p>
                            <p class="text-xs text-gray-500 mt-1">Monthly: ₦<?php echo e(number_format($websiteStat['monthly_revenue'] ?? 0, 2)); ?> • Yearly: ₦<?php echo e(number_format($websiteStat['yearly_revenue'] ?? 0, 2)); ?></p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($websiteStat['today_payments']); ?> payment<?php echo e($websiteStat['today_payments'] != 1 ? 's' : ''); ?></p>
                        </div>
                        <div class="bg-purple-50 rounded-lg p-3 min-w-0 overflow-hidden">
                            <p class="text-xs text-gray-600 mb-1">This Month</p>
                            <p class="text-sm sm:text-base font-bold text-purple-900 break-words leading-tight">₦<?php echo e(number_format($websiteStat['monthly_revenue'], 2)); ?></p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($websiteStat['monthly_payments']); ?> payment<?php echo e($websiteStat['monthly_payments'] != 1 ? 's' : ''); ?></p>
                        </div>
                    </div>
                    <?php if(isset($websiteStat['yearly_revenue'])): ?>
                    <div class="mt-3 pt-3 border-t border-gray-100">
                        <div class="bg-green-50 rounded-lg p-3">
                            <p class="text-xs text-gray-600 mb-1">This Year</p>
                            <p class="text-sm sm:text-base font-bold text-green-900">₦<?php echo e(number_format($websiteStat['yearly_revenue'], 2)); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    </div>
                    
                    <div class="flex flex-wrap items-center gap-3 sm:gap-4 text-xs text-gray-600 mt-3">
                        <span><strong><?php echo e(number_format($websiteStat['total_payments'])); ?></strong> approved</span>
                        <?php if($websiteStat['pending_payments'] > 0): ?>
                            <span class="text-yellow-600"><strong><?php echo e(number_format($websiteStat['pending_payments'])); ?></strong> pending</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        <!-- Recent Transactions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-4 lg:p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 class="text-base lg:text-lg font-semibold text-gray-900">Recent Transactions</h3>
                <a href="<?php echo e(route('business.transactions.index')); ?>" class="text-xs lg:text-sm text-primary hover:underline">View All</a>
            </div>
            <!-- Desktop Table View -->
            <div class="hidden lg:block overflow-x-auto -mx-4 lg:mx-0">
                <div class="inline-block min-w-full align-middle px-4 lg:px-0">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Transaction ID</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Website</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase min-w-[100px]">Amount</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 lg:px-6 py-4">
                                    <a href="<?php echo e(route('business.transactions.show', $payment)); ?>" class="text-xs sm:text-sm font-medium text-primary hover:underline break-words">
                                        <?php echo e(Str::limit($payment->transaction_id, 20)); ?>

                                    </a>
                                </td>
                                <td class="px-4 lg:px-6 py-4 text-xs sm:text-sm text-gray-600">
                                    <?php if($payment->website): ?>
                                        <span class="text-xs truncate block max-w-[150px]" title="<?php echo e($payment->website->website_url); ?>">
                                            <?php echo e(parse_url($payment->website->website_url, PHP_URL_HOST)); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 lg:px-6 py-4 text-xs sm:text-sm text-gray-900 break-words min-w-0">₦<?php echo e(number_format($payment->amount, 2)); ?></td>
                                <td class="px-4 lg:px-6 py-4">
                                    <?php if($payment->status === 'approved'): ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                                    <?php elseif($payment->status === 'pending'): ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 lg:px-6 py-4 text-xs sm:text-sm text-gray-500 whitespace-nowrap"><?php echo e($payment->created_at->format('M d, Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 lg:px-6 py-4 text-center text-xs sm:text-sm text-gray-500">No transactions found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Mobile Card View -->
            <div class="lg:hidden divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('business.transactions.show', $payment)); ?>" class="block p-4 hover:bg-gray-50 transition-colors">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-900 truncate"><?php echo e(Str::limit($payment->transaction_id, 25)); ?></p>
                            <p class="text-xs text-gray-500 mt-1 break-words">
                                <?php if($payment->website): ?>
                                    <?php echo e(parse_url($payment->website->website_url, PHP_URL_HOST)); ?> • 
                                <?php endif; ?>
                                <?php echo e($payment->created_at->format('M d, Y')); ?>

                            </p>
                        </div>
                        <div class="ml-4 text-right flex-shrink-0 min-w-0">
                            <p class="text-sm sm:text-base font-semibold text-gray-900 break-words leading-tight">₦<?php echo e(number_format($payment->amount, 2)); ?></p>
                            <div class="mt-1">
                                <?php if($payment->status === 'approved'): ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                                <?php elseif($payment->status === 'pending'): ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 text-center text-xs sm:text-sm text-gray-500">No transactions found</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Withdrawals -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-4 lg:p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 class="text-base lg:text-lg font-semibold text-gray-900">Recent Withdrawals</h3>
                <a href="<?php echo e(route('business.withdrawals.index')); ?>" class="text-xs lg:text-sm text-primary hover:underline">View All</a>
            </div>
            <!-- Desktop Table View -->
            <div class="hidden lg:block overflow-x-auto -mx-4 lg:mx-0">
                <div class="inline-block min-w-full align-middle px-4 lg:px-0">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase min-w-[100px]">Amount</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th class="px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $recentWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 lg:px-6 py-4 text-xs sm:text-sm text-gray-900 break-words min-w-0">₦<?php echo e(number_format($withdrawal->amount, 2)); ?></td>
                                <td class="px-4 lg:px-6 py-4">
                                    <?php if($withdrawal->status === 'approved'): ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                                    <?php elseif($withdrawal->status === 'pending'): ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                                    <?php elseif($withdrawal->status === 'rejected'): ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">Processed</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 lg:px-6 py-4 text-xs sm:text-sm text-gray-500 whitespace-nowrap"><?php echo e($withdrawal->created_at->format('M d, Y')); ?></td>
                                <td class="px-4 lg:px-6 py-4">
                                    <a href="<?php echo e(route('business.withdrawals.show', $withdrawal)); ?>" class="text-xs sm:text-sm text-primary hover:underline">View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="px-4 lg:px-6 py-4 text-center text-xs sm:text-sm text-gray-500">No withdrawals found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Mobile Card View -->
            <div class="lg:hidden divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $recentWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('business.withdrawals.show', $withdrawal)); ?>" class="block p-4 hover:bg-gray-50 transition-colors">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex-1 min-w-0">
                            <p class="text-sm sm:text-base font-semibold text-gray-900 break-words leading-tight">₦<?php echo e(number_format($withdrawal->amount, 2)); ?></p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($withdrawal->created_at->format('M d, Y')); ?></p>
                        </div>
                        <div class="ml-4 flex-shrink-0">
                            <?php if($withdrawal->status === 'approved'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Approved</span>
                            <?php elseif($withdrawal->status === 'pending'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                            <?php elseif($withdrawal->status === 'rejected'): ?>
                                <span class="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Rejected</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">Processed</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 text-center text-xs sm:text-sm text-gray-500">No withdrawals found</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/checzspw/public_html/resources/views/business/dashboard.blade.php ENDPATH**/ ?>