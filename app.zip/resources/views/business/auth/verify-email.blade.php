<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Email - Payment Gateway</title>
    @if(\App\Models\Setting::get('site_favicon'))
        <link rel="icon" type="image/png" href="{{ asset('storage/' . \App\Models\Setting::get('site_favicon')) }}">
        <link rel="shortcut icon" type="image/png" href="{{ asset('storage/' . \App\Models\Setting::get('site_favicon')) }}">
    @endif
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            DEFAULT: '#3C50E0',
                            dark: '#2E3FB0',
                        },
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
<div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8">
        <div>
            <div class="mx-auto h-16 w-16 bg-primary rounded-lg flex items-center justify-center">
                <i class="fas fa-envelope text-white text-2xl"></i>
            </div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                Verify Your Email Address
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
                We've sent a verification link to your email address
            </p>
        </div>

        <div class="bg-white p-8 rounded-lg shadow-sm border border-gray-200">
            @if (session('status'))
                <div class="mb-4 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
                    {{ session('status') }}
                </div>
            @endif

            @if (session('success'))
                <div class="mb-4 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
                    {{ session('success') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="mb-4 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
                    <ul class="list-disc list-inside text-sm">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="text-center">
                <div class="mb-6">
                    <div class="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-blue-100 mb-4">
                        <i class="fas fa-envelope-open text-blue-600 text-3xl"></i>
                    </div>
                    <p class="text-gray-700 mb-4">
                        Before proceeding, please check your email for a verification link or PIN.
                    </p>
                    <p class="text-sm text-gray-600 mb-6">
                        @if(session('registered_email'))
                            Verification email sent to: <strong>{{ session('registered_email') }}</strong>
                        @else
                        If you didn't receive the email, we can send you another one.
                        @endif
                    </p>
                </div>

                <!-- PIN Verification Form -->
                <div class="mb-6 pb-6 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Verify with PIN</h3>
                    <form method="POST" action="{{ route('business.verification.verify-pin') }}">
                        @csrf
                        <div class="mb-4">
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2 text-left">Email Address</label>
                            <input type="email" name="email" id="email" required 
                                value="{{ session('registered_email') ?? old('email') }}"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                                placeholder="Enter your email">
                        </div>
                        <div class="mb-4">
                            <label for="pin" class="block text-sm font-medium text-gray-700 mb-2 text-left">Verification PIN</label>
                            <input type="text" name="pin" id="pin" required maxlength="6" pattern="[0-9]{6}"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-center text-2xl font-mono tracking-widest"
                                placeholder="000000">
                            <p class="text-xs text-gray-500 mt-1 text-left">Enter the 6-digit PIN from your email</p>
                        </div>
                        <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors">
                            <i class="fas fa-check-circle mr-2"></i>
                            Verify Email with PIN
                        </button>
                    </form>
                </div>

                <!-- Resend Email Form -->
                <form method="POST" action="{{ route('business.verification.send') }}">
                    @csrf
                    @if(session('registered_email'))
                        <input type="hidden" name="email" value="{{ session('registered_email') }}">
                    @endif
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors">
                        <i class="fas fa-paper-plane mr-2"></i>
                        Resend Verification Email
                    </button>
                </form>

                <div class="mt-6">
                    <a href="{{ route('business.login') }}" class="text-sm text-primary hover:text-primary-dark">
                        <i class="fas fa-arrow-left mr-1"></i>
                        Back to Login
                    </a>
                </div>
            </div>

            <div class="mt-8 pt-6 border-t border-gray-200">
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle text-yellow-400"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm text-yellow-700">
                                <strong>Note:</strong> The verification link will expire in 60 minutes. Make sure to check your spam folder if you don't see the email in your inbox.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
