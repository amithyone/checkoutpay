// ================================
// MEVONPAY API Documentation Content
// Complete documentation database for all API endpoints
// ================================

const documentation = {
  // ========== HOME PAGE ==========
  home: {
    title: '', // Empty title since we use Hero section
    subtitle: '',
    sections: [
      {
        title: '', // No section title for Hero
        icon: '',
        content: `
          <div class="hero-section">
            <div class="hero-actions">
              <a href="#/rubies" class="btn-hero" onclick="window.documentation.navigateTo('rubies')">Get Started</a>
              <a href="https://mevonpay.com.ng/en/developers" target="_blank" class="btn-hero outline">Developer Portal</a>
            </div>
          </div>

          <p>The Mevonpay API provides a powerful white-label virtual account solution designed for fintech startups, 
          VTU platforms, wallet applications, and digital banking services.</p>
          
          <div class="alert alert-info">
             <strong>Base URL:</strong> <code>https://api.mevonpay.com.ng</code>
          </div>
        `
      },
      {
        title: '🚀 Getting Started',
        icon: 'fas fa-rocket',
        content: `
          <p>To get started with the MEVONPAY API:</p>
          <ol>
            <li><strong>Create a Mevonpay Account</strong> - Sign up at <a href="https://mevonpay.com.ng/en/signup" target="_blank">mevonpay.com.ng</a></li>
            <li><strong>Complete KYC Verification</strong> - Submit required identity documents</li>
            <li><strong>Register as Merchant</strong> - Activate your merchant account</li>
            <li><strong>Get API Credentials</strong> - Retrieve your API key from the developer dashboard</li>
          </ol>
        `
      },
      {
        title: '🔐 Authentication',
        icon: 'fas fa-shield-alt',
        content: `
          <div class="auth-box">
            <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
            <div class="auth-content">
               <p>All API requests require authentication using your secret token.</p>
               <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
            </div>
            <div class="endpoint-header"><i class="fas fa-globe"></i> API Base URL</div>
            <div class="endpoint-content">
               <div class="code-block mini"><pre><code class="language-http">https://api.mevonpay.com.ng</code></pre></div>
            </div>
          </div>
          
          <div class="alert alert-warning">
            <strong>Security Note:</strong> Never expose your secret token on the client-side. All API requests should be made from your server.
          </div>
        `
      }
    ]
  },

  // ========== PRICING ==========
  pricing: {
    title: 'Pricing & Fees',
    subtitle: 'Transparent pricing for all services',
    sections: [
      {
        title: '💰 Fee Schedule',
        icon: 'fas fa-tags',
        content: `
          <p>Mevonpay offers competitive pricing with no hidden charges. Below is the detailed fee schedule for our services.</p>
          
          <div class="alert alert-info">
            <strong>Note:</strong> Fees are automatically deducted from your wallet balance or the transaction amount.
          </div>

          <h3>Virtual Accounts</h3>
          <table>
            <thead>
              <tr>
                <th>Service</th>
                <th>Fee</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Rubies (Standard)</strong></td>
                <td>0.7%</td>
                <td>Capped at ₦100 per transaction</td>
              </tr>
              <tr>
                <td><strong>Rubies (Direct)</strong></td>
                <td>0.7%</td>
                <td>Capped at ₦100 per transaction</td>
              </tr>
              <tr>
                <td><strong>Paga MFB</strong></td>
                <td>0.8%</td>
                <td>Capped at ₦150 per transaction</td>
              </tr>
              <tr>
                <td><strong>Loma MFB</strong></td>
                <td>0.7%</td>
                <td>Capped at ₦100 per transaction</td>
              </tr>
              <tr>
                <td><strong>Temporary VA</strong></td>
                <td>1.0%</td>
                <td>Flat fee for disposable accounts</td>
              </tr>
              <tr>
                <td><strong>Dynamic VA</strong></td>
                <td>1.5%</td>
                <td>For checkout/one-time payments</td>
              </tr>
            </tbody>
          </table>

          <h3>Transfers</h3>
          <table>
            <thead>
              <tr>
                <th>Amount Range</th>
                <th>Fee</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>₦1 - ₦5,000</td>
                <td>₦10</td>
              </tr>
              <tr>
                <td>₦5,001 - ₦50,000</td>
                <td>₦25</td>
              </tr>
              <tr>
                <td>₦50,001 & Above</td>
                <td>₦50</td>
              </tr>
            </tbody>
          </table>

          <h3>Verification & Other Services</h3>
          <table>
            <thead>
              <tr>
                <th>Service</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>BVN Verification</td>
                <td>₦30 per request</td>
              </tr>
              <tr>
                <td>NIN Verification</td>
                <td>₦50 per request</td>
              </tr>
              <tr>
                <td>OTP SMS</td>
                <td>₦2 - ₦5 per SMS (Network dependent)</td>
              </tr>
              <tr>
                <td>Name Enquiry</td>
                <td>Free</td>
              </tr>
            </tbody>
          </table>

          <h3>Crypto & Wallets</h3>
          <table>
            <thead>
              <tr>
                <th>Service</th>
                <th>Fee</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Wallet Creation</td>
                <td>Free</td>
              </tr>
              <tr>
                <td>Deposit</td>
                <td>1%</td>
              </tr>
              <tr>
                <td>Withdrawal</td>
                <td>Network Fee + 0.5%</td>
              </tr>
              <tr>
                <td>Exchange/Swap</td>
                <td>1% Spread</td>
              </tr>
            </tbody>
          </table>
        `
      }
    ]
  },

  // ========== RUBIES VIRTUAL ACCOUNT ==========
  rubies: {
    title: 'Rubies Virtual Account',
    subtitle: 'Create and manage Rubies MFB virtual accounts',
    sections: [
      {
        title: '📖 Overview',
        icon: 'fas fa-info-circle',
        content: `<p>Initiate virtual account creation, handle OTP verification, and complete the process to generate a dedicated account number.</p>
        
        <div class="auth-box">
          <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
          <div class="auth-content">
             <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
             <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
          </div>
          <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
          <div class="endpoint-content">
             <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createrubies</code></pre></div>
          </div>
        </div>`
      },
      {
        title: '1️⃣ Step 1: Initiate Account',
        icon: 'fas fa-play-circle',
        content: `
          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$authToken = "your_secret_token";
$apiUrl = "{baseurl}/V1/createrubies";

$data = [
    "action" => "initiate",
    "fname" => "John",
    "lname" => "Doe",
    "gender" => "male",
    "phone" => "08012345678",
    "bvn" => "12345678901"
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $authToken",
    "Content-Type: application/json"
]);

$response = curl_exec($ch);
curl_close($ch);
print_r(json_decode($response, true));
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": true,
  "message": "Rubies MFB account created successfully",
  "data": {
    "account_number": "1000002144",
    "account_name": "JOHN DOE",
    "bank_name": "RUBIES MFB",
    "bank_code": "090175",
    "reference": "BUS0000000036"
  }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error Example:</strong> <code>{"status": false, "message": "Invalid BVN"}</code>
          </div>
        `
      },
      {
        title: '2️⃣ Step 2: Submit OTP',
        icon: 'fas fa-check-double',
        content: `
          <p>Verify the OTP sent to the user's phone to complete creation.</p>
          <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$data = [
    "action" => "complete",
    "otp" => "123456",
    "reference" => "ref_abc123"
];

// Send using same cURL structure as Step 1
             </code></pre>
          </div>
        `
      },
      {
        title: '3️⃣ Step 3: Resend OTP',
        icon: 'fas fa-redo',
        content: `
          <p>If OTP expires or is not received.</p>
          <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$data = [
    "action" => "resendOtp",
    "reference" => "ref_abc123"
];

// Send using same cURL structure as Step 1
             </code></pre>
          </div>
        `
      }
    ]
  },

  // ========== BANK TRANSFER ==========
  transfer: {
    title: 'Bank Transfer',
    subtitle: 'Send money to any Nigerian bank',
    sections: [
      {
        title: '📖 Overview',
        icon: 'fas fa-info-circle',
        content: `<p>Initiate real-time fund transfers. This endpoint uses a "Three-Bucket" response system (Success, Pending, Failed).</p>
        
        <div class="auth-box">
          <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
          <div class="auth-content">
             <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
             <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
          </div>
          <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
          <div class="endpoint-content">
             <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createtransfer</code></pre></div>
          </div>
        </div>`
      },
      {
        title: '📡 Endpoint',
        icon: 'fas fa-server',
        content: `
          <p><strong>POST</strong> <code>/V1/createtransfer</code></p>
        `
      },
      {
        title: '🚦 Response Buckets',
        icon: 'fas fa-traffic-light',
        content: `
          <table>
            <thead><tr><th>Status</th><th>Code</th><th>Description</th></tr></thead>
            <tbody>
              <tr><td>SUCCESSFUL</td><td>00</td><td>Transaction completed. Credit reached recipient.</td></tr>
              <tr><td>PENDING</td><td>09, 90, 99</td><td>Processing. Do not refund. Poll status.</td></tr>
              <tr><td>FAILED</td><td>Other</td><td>Transaction failed. Funds reversed.</td></tr>
            </tbody>
          </table>
        `
      },
      {
        title: '💻 PHP Implementation',
        icon: 'fas fa-code',
        content: `
          <div class="code-block">
            <div class="code-header">PHP</div>
            <pre><code class="language-php">
$authToken = 'your secret key';
$transferUrl = '{baseurl}/V1/createtransfer';

$data = [
    "amount" => 5000,
    "bankCode" => "000015",
    "bankName" => "ZENITH BANK PLC",
    "creditAccountName" => "Tunde Badmasu",
    "creditAccountNumber" => "2138908079",
    "debitAccountName" => "Your Name",
    "debitAccountNumber" => "1011110495",
    "narration" => "Payment for services",
    "reference" => "REF123456",
    "sessionId" => "SESSION123",
    "currentPassword" => "your_password"
];

$headers = [
    "Authorization: Bearer $authToken",
    "Content-Type: application/json"
];

$ch = curl_init($transferUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$result = json_decode($response, true);

// Recommended Logic: Handle based on Response Codes
$resCode = $result['responseCode'] ?? '';

if ($resCode === '00') {
    echo "Transfer Successful";
} elseif (in_array($resCode, ['09', '90', '99'])) {
    echo "Transfer Pending - Do not refund user yet. Use /tsq to verify.";
} else {
    echo "Transfer Failed - Funds reversed.";
}

curl_close($ch);
            </code></pre>
          </div>
        `
      }
    ]
  },

  // ========== WEBHOOKS ==========
  webhook: {
    title: 'Webhooks',
    subtitle: 'Real-time notifications for transactions',
    sections: [
      {
        title: '🔔 Funding Events',
        icon: 'fas fa-bell',
        content: `
          <p>Listen for <code>funding.success</code> events for both Naira and Crypto.</p>
        `
      },
      {
        title: '🇳🇬 Naira Payload',
        icon: 'fas fa-money-bill-wave',
        content: `
          <div class="code-block">
            <div class="code-header">JSON</div>
            <pre><code class="language-json">
{
  "event": "funding.success",
  "data": {
    "account_number": "8880000288",
    "amount": 5000,
    "reference": "txn_8d7822",
    "sender": "John Doe",
    "bank_name": "GTBank",
    "timestamp": "2025-06-01 14:25:33"
  }
}
            </code></pre>
          </div>
        `
      },
      {
        title: '₿ Crypto Payload',
        icon: 'fab fa-bitcoin',
        content: `
          <div class="code-block">
            <div class="code-header">JSON</div>
            <pre><code class="language-json">
{
  "event": "funding.success",
  "data": {
    "asset": "USDT",
    "network": "offchain",
    "wallet_address": "TEqgz...",
    "amount": 2,
    "reference": "REF...",
    "description": "Crypto withdrawal"
  }
}
            </code></pre>
          </div>
        `
      },
      {
        title: '💻 Handler Example',
        icon: 'fas fa-code',
        content: `
          <div class="code-block">
            <div class="code-header">PHP Handler</div>
            <pre><code class="language-php">
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (($data['event'] ?? '') === 'funding.success') {
    $funding = $data['data'];
    
    if (isset($funding['account_number'])) {
        // Handle Naira funding
        $amt = $funding['amount'];
        $ref = $funding['reference'];
    } else {
        // Handle Crypto funding
        $asset = $funding['asset'];
        $amt = $funding['amount'];
    }
    
    http_response_code(200);
}
            </code></pre>
          </div>
        `
      }
    ]
  },

  // ========== BANK SERVICES ==========
  'bank-service': {
    title: 'Bank Services',
    subtitle: 'Get bank lists and resolve account names',
    sections: [
      {
        title: '🏦 Get Bank List',
        icon: 'fas fa-university',
        content: `
          <div class="auth-box">
            <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/bank_service</code></pre></div>
             </div>
           </div>

           <p>Retrieve a list of all supported banks.</p>
           <div class="code-block">
             <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$token = "your_secret_key";
$apiUrl = "{baseurl}/V1/bank_service";
$response = callApi(['action' => 'getBankList'], $token, $apiUrl);
print_r($response);

function callApi($postData, $token, $apiUrl) {
    // ... cURL implementation ...
}
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": true,
  "message": "Bank list fetched successfully",
  "data": [
    {"bankName": "Access Bank", "bankCode": "044"},
    {"bankName": "GTBank", "bankCode": "058"}
  ]
}
            </code></pre>
          </div>
        `
      },
      {
        title: '👤 Name Enquiry',
        icon: 'fas fa-user-check',
        content: `
          <p>Verify an account number before transferring funds.</p>
          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$requestData = [
    'action' => 'nameEnquiry',
    'bankCode' => '058',
    'accountNumber' => '1234567890'
];
$response = callApi($requestData, 'your_secret_key', '{baseurl}/V1/bank_service');
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": true,
  "message": "Account name resolved",
  "data": {
    "account_name": "JOHN DOE",
    "account_number": "1234567890",
    "bank_code": "058"
  }
}
            </code></pre>
          </div>
        `
      }
    ]
  },

  // ========== TEMPORARY ACCOUNTS ==========
  'temp-va': {
    title: 'Temporary Virtual Account',
    subtitle: 'Create disposable accounts for one-time payments',
    sections: [
      {
        title: '⏳ Create Account',
        icon: 'fas fa-hourglass-start',
        content: `
          <div class="auth-box">
            <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
            <div class="auth-content">
               <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
               <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
            </div>
            <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
            <div class="endpoint-content">
               <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createtempva</code></pre></div>
            </div>
          </div>

          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$url = "{baseurl}/V1/createtempva";

$data = [
    "fname" => "John",
    "lname" => "Doe",
    "bvn" => "22648075093"
];

$payload = json_encode($data);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization:  your_secret_key',
    'Content-Length: ' . strlen($payload)
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Status Code: " . $httpCode . "\n";
echo "Response:\n" . $response . "\n";
?>  
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
    "status": true,
    "message": "Temporary virtual account created successfully",
    "account_number": "8880012345",
    "account_name": "John Doe",
    "bank_name": "Rubies MFB",
    "bank_code": "090175"
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": false, "message": "Invalid BVN or missing data"}</code>
          </div>
          <div class="alert alert-success">
            <strong>Success Response:</strong> Returns <code>account_number</code>, <code>account_name</code>, <code>bank_name</code>.
          </div>
        `
      }
    ]
  },

  // ========== BVN VERIFICATION ==========
  bvn: {
    title: 'BVN Verification',
    subtitle: 'Identity verification using Bank Verification Number',
    sections: [
      {
        title: '🔍 Verify BVN',
        icon: 'fas fa-id-card',
        content: `
          <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/bvn-verify</code></pre></div>
             </div>
           </div>

          <p><strong>Fee:</strong> ₦30 per successful verification.</p>
          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">   
$url = "{baseurl}/V1/bvn-verify";

$data = [
    "bvn" => "12345678901",
    "dob" => "1990-01-01",
    "firstName" => "John",
    "lastName" => "Doe"
];

$headers = [
    "Authorization: your secret key",
    "Content-Type: application/json"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Status Code: " . $httpCode . "\n";
echo "Response:\n" . $response . "\n";
?>
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
    "status": "success",
    "message": "BVN verification successful. ₦30 debited.",
    "data": {
        "responseCode": "00",
        "fullName": "JOHN DOE",
        "idNumber": "12345678901",
        "dob": "01-01-1990",
        "photo": "https://mevonpay.../BVN123.png"
    }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": "failed", "message": "Invalid BVN"}</code>
          </div>
        `
      }
    ]
  },

  // ========== NIN VERIFICATION ==========
  nin: {
    title: 'NIN Verification',
    subtitle: 'Verify National Identification Numbers',
    sections: [
      {
        title: '🔍 Verify NIN',
        icon: 'fas fa-fingerprint',
        content: `
          <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/nin-verify</code></pre></div>
             </div>
           </div>

          <p><strong>Fee:</strong> ₦50 per successful verification.</p>
          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$url = "{baseurl}/V1/nin-verify";

$data = [
    "idNumber"  => "8634000000",
    "dob"       => "1995-04-05",
    "firstName" => "John",
    "lastName"  => "Doe",
    "reference" => "TEST-REF-" . uniqid()
];

$headers = [
    "Authorization: your_secret_key",
    "Content-Type: application/json",
    "Accept: application/json"
];

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($curl);
curl_close($curl);

echo $response;
?>
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": "success",
  "message": "NIN verification successful. ₦50 debited.",
  "reference": "MEV-NIN-685260D1238FA",
  "nin_details": {
      "fullName": "JOHN DOE",
      "dob": "1995-04-05",
      "idNumber": "86340900030",
      "photo": "https://mevonpay.../NIN863.png"
  }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": "failed", "message": "Invalid NIN"}</code>
          </div>
        `
      }
    ]
  },

  // ========== BULK SMS ==========
  sms: {
    title: 'Bulk SMS',
    subtitle: 'Send SMS messages to multiple recipients',
    sections: [
      {
        title: '📨 Send SMS',
        icon: 'fas fa-sms',
        content: `
          <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/sms-send</code></pre></div>
             </div>
           </div>

          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$url = "{baseurl}/V1/sms-send";

$data = [
    "to" => "2348026238809,2348012345678,2348033345567", // up to 500 numbers
    "msg" => "Bulk SMS test from Mevonpay API.",
    "sender_id" => "MEVONPAY" // optional, max 11 characters
];

$headers = [
    "Authorization: your secret key",
    "Content-Type: application/json"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Status Code: " . $httpCode . "\n";
echo "Response:\n" . $response . "\n";
?>
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": "success",
  "message": "SMS sent successfully",
  "sms_used": 6,
  "raw_response": "234911...~234907..."
}
            </code></pre>
          </div>
          <div class="alert alert-warning">
            Note: Maximum 500 numbers per request. Message limit 905 chars.
          </div>
        `
      }
    ]
  },

  // ========== PAGA ACCOUNTS ==========
  paga: {
    title: 'Paga Account',
    subtitle: 'Create virtual accounts via Paga MFB',
    sections: [
      {
        title: '🏦 Create Account',
        icon: 'fas fa-wallet',
        content: `
          <div class="auth-box">
            <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
            <div class="auth-content">
               <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
               <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
            </div>
            <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
            <div class="endpoint-content">
               <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createpaga</code></pre></div>
            </div>
          </div>

          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$url = "{baseurl}/V1/createpaga";
$apiKey = "your api key";

$data = [
    "action" => "create",
    "fname"  => "tunde",
    "lname"  => "badmasu",
    "phone"  => "08012345678"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: {$apiKey}"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
}
curl_close($ch);

echo "Response:\n";
echo $response;
?>
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
    "status": 1,
    "message": "PAGA account created successfully",
    "data": {
        "account_number": "1234567890",
        "account_name": "Tunde Badmasu",
        "reference": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": 0, "message": "Invalid parameters"}</code>
          </div>
        `
      }
    ]
  },

  // ========== LOMA ACCOUNTS ==========
  loma: {
    title: 'Loma Account',
    subtitle: 'Create virtual accounts via Loma MFB',
    sections: [
      {
        title: '🏦 Create Account',
        icon: 'fas fa-university',
        content: `
           <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createloma</code></pre></div>
             </div>
           </div>

           <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$url = "{baseurl}/V1/createloma";

// Test data payload
$payload = [
    "action" => "create",
    "fname" => "Test",
    "lname" => "User",
    "phone" => "08011112222",
    "dob" => "1990-01-01",
    "bvn" => "22345678901", // Required
    "nin" => "12345678901", // Optional
    "address" => "123 Test Lane, Sandbox City"
];

// Encode payload to JSON
$jsonData = json_encode($payload);

// Initialize cURL
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: your api key"
]);

// Execute cURL request
$response = curl_exec($ch);

// Handle response
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
} else {
    echo "<pre>";
    print_r(json_decode($response, true));
    echo "</pre>";
}

curl_close($ch);
?>
             </code></pre>
           </div>
           <div class="code-block">
             <div class="code-header">JSON Response (Success)</div>
             <pre><code class="language-json">
{
    "status": 1,
    "message": "Account created successfully",
    "data": {
        "account_number": "0039906175",
        "account_name": "Test User",
        "bank_name": "LOMA MFB",
        "bank_code": "999999",
        "reference": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    }
}
             </code></pre>
           </div>
           <div class="alert alert-danger">
             <strong>Error:</strong> <code>{"status": 0, "message": "Invalid BVN or mismatched data"}</code>
           </div>
        `
      }
    ]
  },

  // ========== MEVON RUBIES ==========
  'mevon-rubies': {
    title: 'Mevon Rubies',
    subtitle: 'Direct Rubies MFB integration',
    sections: [
      {
        title: '🏦 Create Account',
        icon: 'fas fa-plus-circle',
        content: `
          <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/mevonrubies</code></pre></div>
             </div>
           </div>

          <div class="code-block">
            <div class="code-header">PHP Request</div>
            <pre><code class="language-php">
$authToken = "your_api_key_here";
$baseurl = "{baseurl}";
$apiUrl = $baseurl . "/V1/mevonrubies";

function sendPostRequest($url, $data, $token) {
    $headers = [
        "Authorization: $token",
        "Content-Type: application/json",
        "Accept: application/json"
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return ["status" => false, "message" => curl_error($ch)];
    }

    curl_close($ch);
    return json_decode($response, true);
}

// Create Rubies Virtual Account
$response = sendPostRequest($apiUrl, [
    "action" => "create",
    "fname"  => "Aishatu",
    "lname"  => "Sadiq",
    "phone"  => "08100000000",
    "dob"    => "1990-01-01",
    "bvn"    => "22222222222",
    "email"  => "tester@example.com"
], $authToken);

print_r($response);
?>
            </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": true,
  "message": "Rubies MFB account created successfully",
  "data": {
    "account_number": "1000002144",
    "account_name": "aishatu SADIQ",
    "bank_name": "RUBIES MFB",
    "bank_code": "090175",
    "reference": "BUS0000000036"
  }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": false, "message": "Invalid action"}</code>
          </div>
        `
      }
    ]
  },

  // ========== USDT / CRYPTO ==========
  'usdt': {
    title: 'Crypto Wallets',
    subtitle: 'Generate USDT, BTC, ETH wallets',
    sections: [
      {
        title: '👛 Create Wallet',
        icon: 'fab fa-bitcoin',
        content: `
          <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createusdt</code></pre></div>
             </div>
           </div>

           <p>Supported Assets: <code>usdt, usdc, bitcoin, eth, bnb</code></p>
           <p>Networks: <code>tron, bsc, ethereum, polygon, solana</code></p>
           <div class="code-block">
              <div class="code-header">PHP Request</div>
              <pre><code class="language-php">
 $url = "{baseurl}/V1/createusdt";
$apiKey = "your api token";

$data = [
    "fname" => "John",
    "lname" => "Doe",
    "asset_type" => "usdc", // Options: usdt, usdc, btc, eth, bnb
    "network" => "polygon"  // Options vary by asset (see table below)
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer {$apiKey}"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
}
curl_close($ch);

echo "Response:\n";
echo $response;
?>
              </code></pre>
           </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
    "status": true,
    "message": "Wallet created successfully",
    "data": {
        "wallet_address": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
        "network": "polygon",
        "asset_type": "usdc",
        "request_id": "USDC_6969CE1B25255"
    }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": false, "message": "Unsupported network for asset"}</code>
          </div>
        `
      },
      {
        title: '💸 Withdraw Crypto',
        icon: 'fas fa-arrow-circle-right',
        content: `
          <p><strong>POST</strong> <code>/V1/crypto_withdraw</code></p>
          <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$authToken = "your_api_key_here";
$baseurl = "{baseurl}";
$apiUrl = $baseurl . "/V1/crypto_withdraw";

$payload = [
    "address"   => "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
    "assetType" => "usdt",
    "network"   => "tron",
    "amount"    => 10.00,
    "pin"       => "1234"
];

$headers = [
    "Authorization: $authToken",
    "Content-Type: application/json",
    "Accept: application/json"
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
curl_close($ch);

print_r(json_decode($response, true));
?>
             </code></pre>
          </div>
          <div class="code-block">
            <div class="code-header">JSON Response (Success)</div>
            <pre><code class="language-json">
{
  "status": true,
  "message": "Withdrawal request submitted",
  "data": {
    "reference": "CRY000000045",
    "amount": 10.00,
    "status": "processing"
  }
}
            </code></pre>
          </div>
          <div class="alert alert-danger">
            <strong>Error:</strong> <code>{"status": false, "message": "Invalid wallet address"}</code>
          </div>
        `
      }
    ]
  },

  // ========== EXCHANGE RATES ==========
  rate: {
    title: 'Exchange Rates',
    subtitle: 'Real-time currency rates',
    sections: [
      {
        title: '📈 Get Rates',
        icon: 'fas fa-chart-line',
        content: `
           <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">GET {baseurl}/V1/rate</code></pre></div>
             </div>
           </div>

           <p>Returns the latest exchange rate of NGN.</p>
           <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$url = "{baseurl}/V1/rate";
$apiKey = "your api key";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: $apiKey",
    "Content-Type: application/json"
]);

$response = curl_exec($ch);
if(curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
}
curl_close($ch);

echo "Response:\n";
echo $response;
?>
             </code></pre>
           </div>
           <div class="code-block">
             <div class="code-header">JSON Response (Success)</div>
             <pre><code class="language-json">
{
    "status": true,
    "message": "Latest exchange rate fetched",
    "data": {
        "rate": "1482.1600",
        "last_updated": "2025-10-30 07:25:18"
    }
}
             </code></pre>
           </div>
        `
      },
      {
        title: '💱 Convert Currency',
        icon: 'fas fa-exchange-alt',
        content: `
           <p><strong>POST</strong> <code>/V1/exchange</code></p>
           <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$url = "{baseurl}/V1/exchange";
$apiKey = "your api key";

$data = [
    "amount" => 1500,
    "from_currency" => "NGN",
    "to_currency" => "USD"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: $apiKey",
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
if(curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
}
curl_close($ch);

echo "Response:\n";
echo $response;
?>
             </code></pre>
           </div>
           <div class="code-block">
             <div class="code-header">JSON Response (Success)</div>
             <pre><code class="language-json">
{
  "status": 1,
  "message": "Conversion successful",
  "data": {
    "from_currency": "NGN",
    "to_currency": "USD",
    "amount": 1500,
    "converted_amount": 0.996
  }
}
             </code></pre>
           </div>
           <div class="alert alert-danger">
             <strong>Error:</strong> <code>{"status": 0, "message": "Invalid parameters"}</code>
           </div>
        `
      }
    ]
  },

  // ========== OTP SEND ==========
  otp: {
    title: 'Send OTP',
    subtitle: 'Send One-Time Passwords via SMS',
    sections: [
      {
        title: '📱 Send Code',
        icon: 'fas fa-mobile-alt',
        content: `
           <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/otp-send</code></pre></div>
             </div>
           </div>

           <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$url = "{baseurl}/V1/otp-send";

$payload = [
    "phone" => "2348111111121",
    "otp" => "5421"
];

$headers = [
    "Authorization: your secret key",
    "Content-Type: application/json"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    echo "HTTP Code: $http\n";
    echo "Response:\n$response";
}

curl_close($ch);
?>
             </code></pre>
           </div>
           <div class="code-block">
             <div class="code-header">JSON Response (Success)</div>
             <pre><code class="language-json">
{
    "status": "success",
    "message": "OTP sent successfully. ₦10 debited.",
    "reference": "OTP-6917DAEDD5F62",
    "phone": "2348111111121"
}
             </code></pre>
           </div>
        `
      }
    ]
  },

  // ========== DYNAMIC ACCOUNT ==========
  dynamic: {
    title: 'Dynamic Account',
    subtitle: 'Checkout temporary accounts',
    sections: [
      {
        title: '⚡ Create Dynamic VA',
        icon: 'fas fa-bolt',
        content: `
           <div class="auth-box">
             <div class="auth-header"><i class="fas fa-shield-alt"></i> Authentication</div>
             <div class="auth-content">
                <p>All requests must include your Secret Key in the header as a Bearer Token.</p>
                <div class="code-block mini"><pre><code class="language-http">Authorization: Bearer your_secret_key</code></pre></div>
             </div>
             <div class="endpoint-header"><i class="fas fa-globe"></i> API Endpoint</div>
             <div class="endpoint-content">
                <div class="code-block mini"><pre><code class="language-http">POST {baseurl}/V1/createdynamic</code></pre></div>
             </div>
           </div>

           <div class="code-block">
             <div class="code-header">PHP Request</div>
             <pre><code class="language-php">
$url = "{baseurl}/V1/createdynamic";
$data = [
    "amount" => 100,
    "currency" => "NGN"
];
             </code></pre>
           </div>
           <div class="code-block">
             <div class="code-header">JSON Response (Success)</div>
             <pre><code class="language-json">
{
    "status": true,
    "message": "Account created successfully",
    "data": {
        "accountNumber": "6590618679",
        "accountName": "Checkout",
        "bankName": "Moniepoint Microfinance Bank",
        "bankCode": "50515",
        "expiresOn": "2026-02-16T13:01:57Z",
        "expiresOnInMins": 5,
        "amount": 100,
        "currency": "NGN",
        "fee": 51,
        "totalPayable": 151
    }
}
             </code></pre>
           </div>
        `
      }
    ]
  }
};

// Make documentation available globally
window.documentation = documentation;
